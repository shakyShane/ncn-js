(function() {

    /**
     * Gallery Code here :)
     */

})();
