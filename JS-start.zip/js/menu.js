(function(window, document) {

    /**
     * Code here :)
     */

})(window, document);